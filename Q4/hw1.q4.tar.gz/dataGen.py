#!/usr/bin/env python
# coding=utf-8
file=open("dataset",'w')
for i in xrange(100):
    for j in xrange(100):
        file.write(str(i*0.001)+'\t'+str(j*0.001)+'\n') 
        for k in xrange(9):
            file.write(str(i*0.001+(k+1)*0.000001)+'\t'+str(j*0.001)+'\n')
file.close()
