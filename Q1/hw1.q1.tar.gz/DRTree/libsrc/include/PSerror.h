/* PSerror.h
|
|	Prototypes of PS error handling functions.
+-----------------------------------------------------------------------------*/
extern int
PSerrSave(
	int	errno);

extern void
PSperror(
	char	*msg);


