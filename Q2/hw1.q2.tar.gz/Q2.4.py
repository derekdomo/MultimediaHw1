#!/usr/bin/env python
# coding=utf-8
import sys
import matplotlib as mpl
mpl.use('Agg')
from  matplotlib import pyplot as plt
from matplotlib.pyplot import savefig
import numpy as np
import math
#Bit shuffle to get the zordering value
def BitShuffle(orders, point, dimension):
    dimensions=len(point)
    value=0
    point.reverse()
    for i in xrange(orders):
        for j in xrange(dimensions):
            value=value+(((point[j]>>i)&1)<<(dimension*i+j))
    return value

#Bit recover
def BitRecover(orders, d, value, draw=1):
    result=[]
    for i in xrange(d):
        temp=0
        for j in xrange(orders):
            temp=temp+(((value>>(d*j+d-i-1))&1)<<j)
        result.append(temp)
    #result.reverse()
    return result

#Zordering value next point
def Znext(orders, dimension):
    value=BitShuffle(orders, point, dimension)+1
    return BitRecover(orders, dimension, value)

#Transform to a two bit array
def HilbertTran(value, orders):
    array=[]
    for i in range(orders):
        v=value%4
        if v==3:
            array.append(2)
        elif v==2:
            array.append(3)
        else:
            array.append(v)
        value=value/4
    return array

def HilbertRecov(array, orders):
    value=0
    for i in range(orders):
        value=value+array[i]*(int(math.pow(4,i)))
    return value

#H-value
def HilbertValue(value, orders):
    array=HilbertTran(value, orders)
    array.reverse()
    for i in xrange(len(array)):
        if array[i]==0:
            for j in xrange(i, len(array)):
                if array[j]==3:
                    array[j]=1
                elif array[j]==1:
                    array[j]=3
        if array[i]==3:
            for j in xrange(i, len(array)):
                if array[j]==2:
                    array[j]=0
                elif array[j]==0:
                    array[j]=2
    array.reverse()
    value=HilbertRecov(array, orders)
    return value
#H-value Back Transform
def HilbertBackTransform(value, orders):
    array=[]
    for i in range(orders):
        array.append(value%4)
        value=value/4
    return array
#H-value Back recover
def HilbertBackRecov(array, orders):
    value=0
    for i in range(orders):
        if array[i]==3:
            array[i]=2
        elif array[i]==2:
            array[i]=3
        value=value+array[i]*int(math.pow(4,i))
    return value
#Back from Hvalue
def HilbertValueBack(value, orders):
    array=HilbertBackTransform(value, orders)
    for i in xrange(len(array)):
        if array[i]==0:
            for j in xrange(i):
                if array[j]==3:
                    array[j]=1
                elif array[j]==1:
                    array[j]=3
        if array[i]==3:
            for j in xrange(i):
                if array[j]==2:
                    array[j]=0
                elif array[j]==0:
                    array[j]=2
    value=HilbertBackRecov(array, orders)
    return value

#Hilbert value next point
def Hnext(orders, point, draw=1):
    value=BitShuffle(orders, point, 2)
    value=HilbertValue(value, orders)
    value=value+1
    value=HilbertValueBack(value, orders) 
    return BitRecover(orders, 2, value, draw)

#draw the z-cure and Hilbert curve
def Draw():
    pointX=[]
    pointY=[]
    for i in xrange(64*64):
        temp=BitRecover(6, 2, i, 0)
        pointX.append(temp[0])
        pointY.append(temp[1])
    #draw the picture for Hilbert
    pointHX=[0]
    pointHY=[0]
    for i in xrange(64*64):
        temp=Hnext(6, [pointHX[-1],pointHY[-1]], 0)
        pointHX.append(temp[0])
        pointHY.append(temp[1])

    plt.figure(1)
    plt.plot(pointX, pointY)
    savefig('Zcurve.pdf')

    plt.figure(2)
    plt.plot(pointHX, pointHY)
    
    savefig('Hcurve.pdf')

#main
Draw()
