#!/usr/bin/env python
# coding=utf-8
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot  as plt
import numpy as np
import math
for i in xrange(1):
    tt="dataset.points"
    file=open(tt)
    lines=file.readlines()
    temp=[]
    for i in xrange(len(lines[0].split(" "))):
        temp.append([])
    for l in lines:
        t=l.split(" ")
        for i in xrange(len(t)):
            #temp[i].append(math.log(float(t[i])))
            temp[i].append((float(t[i])))
    plt.figure()
    plt.loglog(temp[0],temp[1])
    plt.gca().set_ylim([10 ** 4, 10 ** 11])
    plt.grid(True)
    fig = plt.gcf()
    fig.savefig("integral.pdf")
