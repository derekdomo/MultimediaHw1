/* DRerror.h
|
|	Prototypes for DR error handling functions.
+-----------------------------------------------------------------------------*/
extern int
DRerrSave(
	int	errno);

extern void
DRperror(
	char	*msg);


